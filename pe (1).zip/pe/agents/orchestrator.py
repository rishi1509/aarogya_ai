import os
import requests
import json
from typing import Optional
from tools.symptom_checker import analyze_symptoms_from_model
from tools.drug_checker import check_interactions
from tools.reminder_tool import set_reminder
from tools.translator import translate_text, detect_language
from memory.health_memory import HealthMemory

# Groq API constants
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
MODEL_NAME = "llama-3.1-8b-instant"

class OrchestratorAgent:
    """
    Central agent responsible for:
    - Classifying the user's intent
    - Routing the query to the correct tool
    - Handling multilingual input/output
    - Returning structured JSON with confidence & recommended tests
    """

    def __init__(self):
        self.memory = HealthMemory()
        self.knowledge = self._load_knowledge()

    def _load_knowledge(self):
        """Load static health knowledge from JSON"""
        try:
            with open("health_knowledge.json", "r", encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            print("Warning: health_knowledge.json not found or invalid.")
            return []

    def _classify_intent(self, query: str) -> str:
        """Classify the query into SYMPTOM_CHECK, DRUG_INTERACTION, REMINDER, or KNOWLEDGE"""
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            return "KNOWLEDGE_NETWORK_FAIL"

        # Include recent history for context
        recent_history = self.memory.get_recent_history(limit=2)
        history_str = "\n".join([f"Q: {h['query']} A: {h['response']}" for h in recent_history])

        prompt = f"""
        Classify the following user query into ONE of these intents:
        - SYMPTOM_CHECK: User describes physical symptoms or wants a diagnosis/assessment.
        - DRUG_INTERACTION: User asks about mixing medications or supplements.
        - REMINDER: User asks to schedule/manage a health-related task.
        - KNOWLEDGE: User asks a general fact-based health question.

        --- RECENT CONTEXT ---
        {history_str if history_str else 'No recent history.'}
        --- CURRENT QUERY ---
        "{query}"
        Respond ONLY with the single, capitalized intent word.
        """

        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        payload = {
            "model": MODEL_NAME,
            "messages": [
                {"role": "system", "content": "You are a specialized health query intent classifier."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.0,
            "max_tokens": 20
        }

        try:
            response = requests.post(GROQ_URL, headers=headers, json=payload, timeout=10)
            response.raise_for_status()
            data = response.json()
            intent = data['choices'][0]['message']['content'].strip().upper()
            if intent in ["SYMPTOM_CHECK", "DRUG_INTERACTION", "REMINDER", "KNOWLEDGE"]:
                return intent
            return "KNOWLEDGE"
        except requests.exceptions.RequestException:
            return "KNOWLEDGE_NETWORK_FAIL"
        except Exception:
            return "KNOWLEDGE_NETWORK_FAIL"

    def _get_general_knowledge(self, query: str, force_static: bool = False) -> str:
        """Return static knowledge or fallback LLM answer"""
        query_words = set(query.lower().split())

        # Static knowledge lookup
        for entry in self.knowledge:
            if any(kw in query_words for kw in entry.get("keywords", [])):
                return f"Static Health Information: {entry.get('text', 'Information found but text missing.')}"

        # LLM fallback
        if not force_static:
            return self._run_llm_knowledge_fallback(query)
        return "General Health Information: Could not find relevant static data, and network is unavailable."

    def _run_llm_knowledge_fallback(self, query: str) -> str:
        """Use LLM for general knowledge queries"""
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            return "General Health Information: LLM query failed because GROQ_API_KEY is missing."

        prompt = f"Answer the following health question concisely: {query}"
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        payload = {
            "model": MODEL_NAME,
            "messages": [
                {"role": "system", "content": "You are a concise and helpful general health knowledge source."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.5
        }

        try:
            response = requests.post(GROQ_URL, headers=headers, json=payload, timeout=15)
            response.raise_for_status()
            data = response.json()
            return f"General Health Information: {data['choices'][0]['message']['content'].strip()}"
        except requests.exceptions.RequestException:
            return "General Health Information: **Connection Error**"
        except Exception as e:
            return f"General Health Information: Unexpected error: {e}"

    def run_query(self, query: str, uploaded_file=None, preferred_lang="Auto") -> str:
        """
        Main entry point:
        - Detect language
        - Translate input
        - Classify intent & route
        - Always return structured JSON for SYMPTOM_CHECK
        """
        detected_lang = detect_language(query)
        query_en = translate_text(query, "en") if detected_lang != "en" else query

        if uploaded_file:
            query_en += " (User uploaded an image, include context)"

        intent = self._classify_intent(query_en)
        response = ""

        # SYMPTOM_CHECK (or fallback)
        if intent == "SYMPTOM_CHECK":
            response = analyze_symptoms_from_model(query_en, uploaded_file)

        # Network failure: still run symptom analysis so frontend has confidence scores
        elif intent == "KNOWLEDGE_NETWORK_FAIL":
            response = analyze_symptoms_from_model(query_en, uploaded_file)
            # Append warning for user
            try:
                data = json.loads(response.strip("```json").strip("```"))
                data["warning"] = "Network failure for knowledge queries; only local symptom analysis shown."
                response = f"```json\n{json.dumps(data, indent=2)}\n```"
            except Exception:
                pass

        elif intent == "DRUG_INTERACTION":
            response = check_interactions(query_en)

        elif intent == "REMINDER":
            response = set_reminder(query_en)

        elif intent == "KNOWLEDGE":
            response = self._get_general_knowledge(query_en)

        else:
            response = "Agent failed to classify intent."

        # Translate output back to user language
        output_lang = {"Auto": detected_lang, "English": "en", "Hindi": "hi", "Marathi": "mr"}.get(preferred_lang, detected_lang)
        if output_lang != "en":
            response = translate_text(response, output_lang)

        # Save to memory
        self.memory.save_entry(query, response)
        return response
