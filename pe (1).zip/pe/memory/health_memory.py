import json
import os
from datetime import datetime

class HealthMemory:
    """
    Manages the storage and retrieval of user queries and agent responses
    in a JSON file, acting as a simple persistent memory store.
    """
    def __init__(self, path="health_memory.json"):
        # We use a path relative to the root for simplicity in this structure
        self.path = os.path.join("memory", path)

        # Ensure the 'memory' directory exists
        os.makedirs(os.path.dirname(self.path), exist_ok=True)

        # Initialize the JSON file if it doesn't exist
        if not os.path.exists(self.path):
            with open(self.path, "w") as f:
                json.dump([], f)

    def save_entry(self, query: str, response: str):
        """
        Saves a new query and response pair with a timestamp.
        """
        timestamp = datetime.now().isoformat()
        new_entry = {
            "timestamp": timestamp,
            "query": query,
            "response": response
        }
        
        try:
            with open(self.path, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            # Handle empty or corrupted file by starting a new list
            data = []
        
        data.append(new_entry)
        
        with open(self.path, "w") as f:
            json.dump(data, f, indent=2)

    def get_recent_history(self, limit: int = 5) -> list[dict]:
        """
        Retrieves the 'limit' number of most recent entries, used for the UI display.
        """
        try:
            with open(self.path, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return []
        
        # Return the last 'limit' items (most recent)
        return data[-limit:][::-1] # [::-1] reverses the list to show most recent first