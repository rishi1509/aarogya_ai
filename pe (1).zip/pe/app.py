import streamlit as st
import json
import re
from datetime import datetime
from io import BytesIO
import speech_recognition as sr
from st_audiorec import st_audiorec
from gtts import gTTS
# Assuming agents.orchestrator and tools.translator are available in your environment
from agents.orchestrator import OrchestratorAgent 
from tools.translator import translate_text, detect_language, SUPPORTED_LANGUAGES 
import base64

# --- Page Configuration ---
st.set_page_config(
    page_title="Aarogya AI",
    layout="wide",
    initial_sidebar_state="expanded",
)

# --- Background Image ---
def set_background_image(image_file):
    try:
        with open(image_file, "rb") as image:
            encoded = base64.b64encode(image.read()).decode()
        st.markdown(
            f"""
            <style>
            .stApp {{
                background-image: url("data:image/jpg;base64,{encoded}");
                background-size: cover;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-position: center;
            }}
            </style>
            """,
            unsafe_allow_html=True
        )
    except FileNotFoundError:
        st.warning(f"Background image not found at: {image_file}. Using default theme.")

# NOTE: Ensure this path is correct for your environment.
set_background_image("/Users/sanskritijha/Downloads/bg.png") 

# --- TTS Helper ---
tts_placeholder = st.empty()
tts_audio = None
def speak_text(text, lang="en"):
    global tts_audio
    if not text.strip():
        return
    tts = gTTS(text=text, lang=lang)
    fp = BytesIO()
    tts.write_to_fp(fp)
    fp.seek(0)
    tts_audio = fp.read()
    tts_placeholder.audio(tts_audio, format='audio/mp3', start_time=0, autoplay=True)

def stop_audio():
    global tts_audio
    tts_placeholder.empty()
    tts_audio = None

# --- Routing Card Helper ---
def create_routing_card(intent_name, color, message_prefix="Query was handled by the"):
    return f"""
        <div style="background-color: rgba(26, 35, 126, 0.85); padding: 10px 20px; border-radius: 8px; margin-bottom: 20px; border-left: 5px solid {color}; color: white;">
            <strong>🚀 Agent Routing Status:</strong> {message_prefix} 
            <span style="color: {color}; font-weight: bold;">{intent_name}</span> tool.
        </div>
    """

# --- Styling ---
st.markdown("""
<style>
.main-header { font-size: 3em !important; font-weight: 900 !important; color: #1A237E !important; text-align:center; margin-bottom:0.3em !important; }
.subheader { font-size: 2.2em; color: #2E3A59; text-align:center; margin-bottom:1em; }
[data-testid="stForm"] { background-color: rgba(255,255,255,0.85); padding: 30px; border-radius:16px; box-shadow: 0 8px 30px rgba(0,0,0,0.3); border:1px solid #3498DB; }
[data-testid="stForm"] textarea { background-color: rgba(255,255,255,0.9); color:#1A237E; border:1px solid #3498DB; border-radius:8px; }
.stButton>button { background-color: #1ABC9C; color:#FFF; border-radius:8px; font-weight:bold; transition:0.3s; }
.stButton>button:hover { background-color:#16A085; transform:translateY(-1px); }
[data-testid="stSidebar"] { background-color: rgba(26,35,126,0.85); color:white; }
[data-testid="stMetricValue"] { color:#F1C40F; }
</style>
""", unsafe_allow_html=True)

# --- Header ---
st.markdown('<p class="main-header">Aarogya AI 🩺💊 </p>', unsafe_allow_html=True)
st.markdown('<p class="subheader">AI-Powered Health Agent - Connecting rural India with reliable health knowledge.</p>', unsafe_allow_html=True)

# --- Initialize Agent and Session State ---
if "agent" not in st.session_state:
    st.session_state.agent = OrchestratorAgent()
agent = st.session_state.agent

if 'voice_lang_code' not in st.session_state:
    st.session_state.voice_lang_code = None

# --- Sidebar: Clear History ---
st.sidebar.markdown("### 📚 Search History")
if 'clear_history' not in st.session_state:
    st.session_state.clear_history = False
if st.sidebar.button("Clear History"):
    if hasattr(agent.memory, "history"):
        agent.memory.history = []
    st.session_state.clear_history = True
    st.rerun() 

# --- Display History ---
try:
    history = agent.memory.get_recent_history(limit=7) if hasattr(agent.memory, "get_recent_history") else []
    if history and not st.session_state.clear_history:
        for i, entry in enumerate(history):
            dt = datetime.fromisoformat(entry['timestamp']) if 'timestamp' in entry else datetime.now()
            date_str = dt.strftime("%Y-%m-%d")
            short_query = entry['query'][:30] + "..." if len(entry['query']) > 30 else entry['query']
            with st.sidebar.expander(f"**{i+1}.** {short_query} ({date_str})"):
                st.markdown(f"**Query:**\n> {entry['query']}")
                st.markdown("---")
                st.markdown(f"**Agent Response:**\n{entry['response']}")
    elif st.session_state.clear_history or not history:
        st.sidebar.info("No past queries found. Start your first analysis!")
except Exception as e:
    st.sidebar.error(f"History error: {e}")

# --- Main Content ---
response_container = st.empty()
routing_card_container = st.empty()

with st.form(key='query_form', clear_on_submit=True):
    st.markdown("#### Enter Your Health Query")
    query = st.text_area(
        "Describe your symptoms, medications, or health query:",
        height=50,
        placeholder="E.g., 'I have a fever and headache, what should I do?'"
    )
    
    st.markdown("---") # Visual separator
    
    # --- NEW: Language Selector ---
    voice_language = st.radio(
        "Select your preferred language:",
        ('English', 'Hindi', 'Marathi'),
        horizontal=True,
        key='voice_lang'
    )
    
    st.markdown("🎙️ Record your query:")
    voice_data = st_audiorec()
    voice_query = ""
    
    st.session_state.voice_lang_code = None 

    if voice_data:
        # --- NEW: Language mapping dictionary ---
        lang_code_map = {
            'English': 'en-IN',
            'Hindi': 'hi-IN',
            'Marathi': 'mr-IN'
        }
        selected_lang_code = lang_code_map[voice_language]
        
        recognizer = sr.Recognizer()
        
        # --- CHANGED: Removed the loop, now uses the selected language directly ---
        try:
            with sr.AudioFile(BytesIO(voice_data)) as source:
                audio = recognizer.record(source)
                recognized_text = recognizer.recognize_google(audio, language=selected_lang_code) 
            
            if recognized_text.strip():
                voice_query = recognized_text
                st.success(f"Recognized Voice Query: {voice_query}")
                st.session_state.voice_lang_code = selected_lang_code
            else:
                st.error("Could not understand the audio, please try again.")

        except Exception as e:
            st.error(f"Speech recognition error: Could not understand audio from the selected language. Please try again.")
            
    uploaded_file = st.file_uploader(
        "Upload an image (optional)", type=["jpg", "png", "jpeg"],
        help="Upload an image of a rash or prescription label."
    )
    submit_button = st.form_submit_button(label='Analyze Health Query', type="primary", use_container_width=True)

# --- Submission Logic (This section is now correct and robust) ---
final_query = query.strip() if query.strip() else voice_query.strip()
image_uploaded = uploaded_file is not None

if submit_button and (final_query or image_uploaded):
    routing_card_container.empty()
    with st.status("🧠 Initiating Multi-Agent Workflow...", expanded=True) as status:
        
        detected_lang = "en" # Default to English
        
        # 1. Prioritize the language from the successful voice recognition
        if st.session_state.voice_lang_code:
            voice_lang = st.session_state.voice_lang_code
            if voice_lang.startswith("hi"):
                detected_lang = "hi"
            elif voice_lang.startswith("mr"):
                detected_lang = "mr"
            else: # Catches "en-IN", "en-US", etc.
                detected_lang = "en"
        # 2. Fallback to text detection if no voice was used
        elif final_query:
            try:
                detected_lang = detect_language(final_query)[:2]
            except:
                detected_lang = "en" 
        
        tts_lang_code = {"hi":"hi","mr":"mr","en":"en"}.get(detected_lang,"en") 
        query_for_agent = translate_text(final_query, "en") if detected_lang != "en" else final_query
        
        status.update(label="🩺💊 Determining intent and routing to specialized tool...")
        raw_response = agent.run_query(query_for_agent, uploaded_file, preferred_lang="en")  
        status.update(label="✨ Translating and displaying results...")
        
        # --- The rest of your processing logic is fine ---
        with response_container.container():
            st.markdown("### 📊 Agent Response Summary")
            
            try:
                match = re.search(r"```json\s*([\s\S]+?)\s*```", raw_response)
                if match:
                    data = json.loads(match.group(1))
                    determined_intent = data.get("intent", "SYMPTOM_CHECK") 
                    simple_advice = data.get("simple_advice", "")
                    conditions = data.get("possible_conditions", [])
                    drug_warnings = data.get("medication_safety_check", [])
                else:
                    data, simple_advice, conditions, drug_warnings = {}, "", [], []
                    if "drug" in raw_response.lower() or "interaction" in raw_response.lower():
                         determined_intent = "DRUG_CHECKER_TOOL_FAIL"
                         simple_advice = "The system routed your query to a medication safety tool but couldn't get structured data. **Always consult a registered pharmacist or doctor**."
                    else:
                        determined_intent = "SYMPTOM_CHECK_FAIL"
                        simple_advice = raw_response 
                    data['confidence_score'] = 15 
                    
            except Exception as e:
                data = {}
                simple_advice = "A technical error occurred while processing the information. For safety, please consult a healthcare professional."
                conditions, drug_warnings = [], []
                determined_intent = "ERROR_PARSING_FAIL"
                data['confidence_score'] = 10
            
            display_advice = translate_text(simple_advice, detected_lang) if simple_advice and detected_lang != 'en' else simple_advice
            
            display_conditions, display_drug_warnings = [], []
            full_text_for_speech = ""
            conf_score = round(data.get('confidence_score', 0))
            
            conf_score_phrase = translate_text(f"Overall confidence score is {conf_score} percent. ", detected_lang)
            full_text_for_speech += conf_score_phrase

            if determined_intent in ["SYMPTOM_CHECK", "MEDICAL_KNOWLEDGE"] and conditions:
                for cond in conditions:
                    name_t = translate_text(cond.get('name', ''), detected_lang)
                    relevance_t = translate_text(cond.get('relevance', ''), detected_lang)
                    tests_t = [translate_text(t, detected_lang) for t in cond.get('tests', [])]
                    display_conditions.append({'name': name_t, 'score': cond.get('score', 0), 'relevance': relevance_t, 'tests': tests_t})
                    score = round(cond.get('score', 0), 1)
                    score_phrase = translate_text(f"{score} out of 10 chance.", detected_lang)
                    full_text_for_speech += f"{name_t}. {score_phrase}. "
            
            elif determined_intent.startswith("DRUG_CHECKER") and drug_warnings:
                for warn in drug_warnings:
                    type_t = translate_text(warn.get('warning_type', ''), detected_lang)
                    desc_t = translate_text(warn.get('description', ''), detected_lang)
                    display_drug_warnings.append({'type': type_t, 'description': desc_t})
                    full_text_for_speech += f"{type_t}. {desc_t}. "

            if display_advice:
                advice_phrase = translate_text("Advice: ", detected_lang)
                full_text_for_speech += f"{advice_phrase} {display_advice}"

            card_html = create_routing_card(determined_intent, "#3498DB", "Query was directed to the")
            routing_card_container.markdown(card_html, unsafe_allow_html=True)
            
            st.metric(label="Overall Confidence Score", value=f"{conf_score}%")
            
            if determined_intent in ["SYMPTOM_CHECK", "MEDICAL_KNOWLEDGE"]:
                if display_conditions:
                    st.markdown("#### **Possible Conditions Analysis**")
                    for cond in display_conditions:
                        st.info(f"**{cond.get('name', '')} ({round(cond.get('score', 0), 1)}/10 chance)**")
                        st.markdown(f"*{cond.get('relevance','')}*")
                        if cond.get('tests'):
                            st.markdown("🧪 **Recommended Tests:**")
                            st.write(", ".join(cond.get('tests')))
            
            elif determined_intent == "DRUG_CHECKER":
                if display_drug_warnings:
                    st.markdown("#### 💊 **Medication Safety Check Results**")
                    for warn in display_drug_warnings:
                        warn_type = warn['type']
                        if "critical" in warn_type.lower() or "severe" in warn_type.lower():
                            st.error(f"**🚨 {warn_type}**")
                        elif "major" in warn_type.lower() or "moderate" in warn_type.lower():
                            st.warning(f"**⚠️ {warn_type}**")
                        else:
                            st.success(f"**🟢 {warn_type}**")
                        st.markdown(f"*{warn['description']}*")
            
            st.success("### 💊 Simple Advice")
            if display_advice:
                st.markdown(f"> {display_advice}")
            
            if full_text_for_speech.strip():
                speak_text(full_text_for_speech, lang=tts_lang_code)
            
        status.update(label="✅ Analysis Complete! Results Displayed.", state="complete")
        st.button("Stop", on_click=stop_audio)

elif submit_button and not final_query and not image_uploaded:
    st.error("Please enter a query, record a voice prompt, or upload an image before submitting.")
