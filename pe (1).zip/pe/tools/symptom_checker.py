import os
import requests
import json
from typing import Optional

# Groq API constants
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
MODEL_NAME = "llama-3.1-8b-instant"

def analyze_symptoms_from_model(full_query: str, image_data: Optional[str] = None) -> str:
    """
    Analyze user symptoms using LLM and return structured JSON.
    
    Returns:
    - overall confidence (0-100)
    - possible conditions with scores 0-10
    """
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        return json.dumps({
            "intent": "SYMPTOM_CHECK",
            "confidence_score": 0,
            "possible_conditions": [],
            "simple_advice": "GROQ_API_KEY not set. Cannot process request."
        }, indent=2)

    symptoms = full_query.strip() or "No symptoms provided."
    medications = "None"

    json_schema_definition = {
        "intent": "SYMPTOM_CHECK",
        "confidence_score": 0,
        "possible_conditions": [
            {
                "name": "",
                "score": 0,
                "relevance": "",
                "tests": []
            }
        ],
        "simple_advice": "",
        "drug_interaction_warnings": []
    }

    system_prompt = f"""
You are a medical triage AI.
User symptoms: {symptoms}.
Medications: {medications}.
Return JSON strictly following this schema:
- overall confidence_score: 0-100
- each condition score: 0-10
Only return JSON. Example schema: {json.dumps(json_schema_definition, indent=2)}
"""

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": MODEL_NAME,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Analyze symptoms: {symptoms}"}
        ],
        "temperature": 0.4
    }

    try:
        response = requests.post(GROQ_URL, headers=headers, json=payload, timeout=20)
        response.raise_for_status()
        raw_json_text = response.json()['choices'][0]['message']['content']
        parsed = json.loads(raw_json_text)

        # Ensure overall confidence is 0-100
        parsed['confidence_score'] = min(max(parsed.get('confidence_score', 0), 0), 100)

        # Ensure each condition score is 0-10
        for cond in parsed.get('possible_conditions', []):
            cond['score'] = min(max(cond.get('score', 0), 0), 10)

        return f"```json\n{json.dumps(parsed, indent=2)}\n```"

    except Exception as e:
        return json.dumps({
            "intent": "SYMPTOM_CHECK",
            "confidence_score": 0,
            "possible_conditions": [],
            "simple_advice": f"Failed to process symptoms: {e}"
        }, indent=2)
