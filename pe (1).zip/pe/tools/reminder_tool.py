# tools/reminder_tool.py
import os
import json
from datetime import datetime, timedelta

def set_reminder(query: str) -> str:
    """
    Analyzes the user's query to extract the reminder task and time,
    and simulates saving it to a persistence layer (e.g., Firestore).
    
    This function demonstrates the logic for the REMINDER_TOOL.
    
    NOTE: For the final project, this function should be modified to accept a 
    VectorStore/Firestore client object and save the structured reminder data 
    persistently to the database.
    """
    
    query_lower = query.lower()
    task = "Unknown task"
    time_str = "Unknown time"
    
    # --- Multi-Step Prompting Simulation for Task Extraction ---
    
    # 1. Simple task extraction (assuming the Orchestrator LLM passed the right query)
    if "take my pills" in query_lower:
        task = "Take medication/pills."
    elif "appointment" in query_lower:
        task = "Attend a scheduled appointment."
    elif "check blood pressure" in query_lower:
        task = "Check blood pressure reading."
        
    # 2. Simple time extraction (e.g., finding common time keywords)
    now = datetime.now()
    if "tomorrow" in query_lower:
        # Default guess for tomorrow if no time is specified
        time_str = (now + timedelta(days=1)).strftime("%Y-%m-%d") + " at 8:00 AM" 
        
        if "8 am" in query_lower or "8 o'clock" in query_lower:
             time_str = (now + timedelta(days=1)).strftime("%Y-%m-%d") + " at 8:00 AM"
        elif "noon" in query_lower:
            time_str = (now + timedelta(days=1)).strftime("%Y-%m-%d") + " at 12:00 PM"
    
    elif "today" in query_lower or "in an hour" in query_lower:
        time_str = (now + timedelta(hours=1)).strftime("%Y-%m-%d %I:%M %p")
    else:
        # Fallback to a general "soon" time
        time_str = (now + timedelta(minutes=30)).strftime("%Y-%m-%d %I:%M %p")

    
    # --- Structured Output ---
    
    # This JSON structure includes a placeholder for a future Firestore ID
    simulated_response = {
        "intent": "REMINDER",
        "status": "SUCCESS",
        "task_details": {
            "id": "placeholder_firestore_id_" + str(hash(query)),
            "task": task,
            "scheduled_time": time_str,
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        },
        "confirmation_message": f"Reminder set successfully! We will remind you to '{task}' on {time_str}."
    }
    
    return f"```json\n{json.dumps(simulated_response, indent=2)}\n```"
