import os
import json

def check_interactions(drugs_and_substances: str) -> str:
    """
    Performs a simulated drug-drug or drug-substance interaction check.
    
    The LLM must first extract all relevant drug names, supplements, or
    substances from the user's *original query* and pass them as a single,
    comma-separated string to this function.

    E.g., "warfarin, disprin, crocin"

    The function then processes these extracted items against its simulated
    pharmacological database and returns a structured JSON warning.
    
    :param drugs_and_substances: Comma-separated string of extracted items.
    :return: A JSON string containing the analysis result.
    """
    
    # 1. Normalize and process the input string from the LLM
    items = [item.strip().lower() for item in drugs_and_substances.split(',')]
    
    warnings = []
    confidence = 90  # Start with high confidence in the tool's execution
    
    # --- Simulated Interaction Logic: Drug Class Identification ---
    
    # Check for core components (updated with common brand names)
    has_anticoagulant = any(d in items for d in ["anticoagulant", "warfarin", "blood thinner"])
    
    # NSAIDs (Ibuprofen, Naproxen, Aspirin/Disprin, Flexon contains Ibuprofen)
    has_nsaid = any(d in items for d in ["nsaid", "ibuprofen", "advil", "motrin", "naproxen", "aleve", "disprin", "aspirin", "flexon"])
    
    # Paracetamol/Acetaminophen (Crocin, Tylenol, Paracetamol, Flexon contains Paracetamol)
    has_paracetamol = any(d in items for d in ["tylenol", "acetaminophen", "paracetamol", "crocin", "dologesic", "flexon"])
    
    # Other common substances
    has_statin = "statin" in items
    has_grapefruit = any(d in items for d in ["grapefruit", "grapefruit juice", "pomelo"])
    has_alcohol = any(d in items for d in ["alcohol", "beer", "whisky", "liquor", "drink"])
    
    # Default advice text, updated later if interaction is found
    simple_advice_text = "No critical interaction detected for the mentioned items. Always consult a pharmacist or physician before combining any medications."
    
    # --- Interaction Checks (Prioritized from Severe to Moderate) ---

    # 1. CRITICAL: NSAID (Disprin/Flexon) + Anticoagulant (Warfarin)
    if has_nsaid and has_anticoagulant:
        warnings.append({
            "warning_type": "CRITICAL RISK: Internal Bleeding/Hemorrhage",
            "description": "Combining NSAIDs (like Disprin, Ibuprofen, or Flexon) with anticoagulants (like Warfarin) creates a major and immediate risk of severe internal bleeding, especially GI bleeding. Immediate medical consultation is required."
        })
        confidence = 100
        simple_advice_text = "STOP IMMEDIATELY: This combination carries a critical risk of internal bleeding. Do not take them together without direct medical guidance."
        
    # 2. MAJOR: Paracetamol (Crocin) + Alcohol
    elif has_paracetamol and has_alcohol:
        warnings.append({
            "warning_type": "MAJOR RISK: Liver Toxicity",
            "description": "Combining Paracetamol (Crocin, Dolo) and alcohol, especially in large amounts, significantly increases the risk of severe and potentially fatal liver damage (hepatotoxicity). Use caution and limit alcohol intake."
        })
        confidence = 95
        simple_advice_text = "Major interaction detected: Limit or avoid alcohol entirely when taking Paracetamol/Crocin to prevent liver damage. Follow dosage instructions carefully."

    # 3. MAJOR: Drug-Food interaction (Statin + Grapefruit)
    elif has_statin and has_grapefruit:
        warnings.append({
            "warning_type": "MAJOR FOOD INTERACTION: Increased Drug Levels",
            "description": "Grapefruit products can significantly interfere with the metabolism of statins, dangerously increasing the concentration of the drug in your blood. This can raise the risk of severe side effects like muscle damage (rhabdomyolysis)."
        })
        confidence = 90
        simple_advice_text = "Avoid consuming grapefruit or grapefruit juice while taking statins. Consult your healthcare provider about dietary restrictions."
        
    # 4. GENERAL: Check for Flexon/Ibuprofen usage alone (as requested in prior context)
    elif "flexon" in items or "ibuprofen" in items:
        warnings.append({
            "warning_type": "Standard Painkiller/Fever Check",
            "description": "Ibuprofen and Flexon are standard NSAID painkillers. Use only as directed for short-term relief (typically 3 days max). Avoid if you have stomach issues or kidney problems."
        })
        confidence = 70
        simple_advice_text = "Take Ibuprofen/Flexon only as directed. If symptoms persist or you have underlying health issues, consult a doctor."

    # 5. Default/Low Confidence Scenario
    else:
        # If the LLM successfully extracted items but no known interaction was found.
        # This low confidence encourages the LLM to search for the specific interaction.
        warnings.append({
            "warning_type": "No Critical Interactions Found (Low Confidence)",
            "description": f"The tool checked for interactions among the identified items: {', '.join(items)}. No critical interaction was found in the hard-coded database. This result should be verified with an external search or pharmacist, especially for unfamiliar drugs."
        })
        confidence = 65

    # --- Structured JSON Output for LLM ---
    simulated_response = {
        "tool_name": "check_interactions",
        "input_items": items,
        "warnings": warnings,
        "simple_advice": simple_advice_text,
        "confidence_score": confidence
    }
    
    # Return the JSON string wrapped in markdown for clear transmission
    return f"```json\n{json.dumps(simulated_response, indent=2)}\n```"

# --- End of check_interactions function ---
