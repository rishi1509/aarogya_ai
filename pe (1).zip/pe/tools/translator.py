# tools/translator.py
from googletrans import Translator

translator = Translator()

SUPPORTED_LANGUAGES = {
    "en": "English",
    "hi": "Hindi",
    "mr": "Marathi"
}

def translate_text(text: str, target_lang: str) -> str:
    """Translate text to target language code: en, hi, mr"""
    if not text:
        return text
    try:
        result = translator.translate(text, dest=target_lang)
        return result.text
    except Exception as e:
        print(f"Translation error: {e}")
        return text

def detect_language(text: str) -> str:
    """Detect the language of the input text"""
    if not text:
        return "en"
    try:
        result = translator.detect(text)
        return result.lang
    except Exception as e:
        print(f"Language detection error: {e}")
        return "en"
